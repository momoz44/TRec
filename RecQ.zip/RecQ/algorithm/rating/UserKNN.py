# -*- coding: utf-8 -*-
from baseclass.Recommender import Recommender
from tool import qmath
from structure.symmetricMatrix import SymmetricMatrix
import numpy as np

class UserKNN(Recommender):
    def __init__(self,conf,trainingSet=None,testSet=None,fold='[1]'):
        super(UserKNN, self).__init__(conf,trainingSet,testSet,fold)
        # 根据创建用户相似矩阵，传入的是以上值
        # 传入shape其实是为了创建相应的矩阵大小，但后改用为dict去存储更为方便
        self.userSim = SymmetricMatrix(len(self.dao.user))

    def readConfiguration(self):
        super(UserKNN, self).readConfiguration()
        self.sim = self.config['similarity']
        self.shrinkage =int(self.config['num.shrinkage'])
        self.neighbors = int(self.config['num.neighbors'])

    def printAlgorConfig(self):
        "show algorithm's configuration"
        super(UserKNN, self).printAlgorConfig()
        print 'Specified Arguments of',self.config['recommender']+':'
        print 'num.neighbors:',self.config['num.neighbors']
        print 'num.shrinkage:', self.config['num.shrinkage']
        print 'similarity:', self.config['similarity']
        print '='*80

    def initModel(self):
        self.computeCorr()

    def predict(self,u,i):
        #find the closest neighbors of user u
        #关于dict基于值的排序！不用转化成list再去排！！
        topUsers = sorted(self.userSim[u].iteritems(),key = lambda d:d[1],reverse=True)
        userCount = self.neighbors
        if userCount > len(topUsers):
            userCount = len(topUsers)
        #predict
        sum,denom = 0,0
        #定量取数据的方法！！！
        for n in range(userCount):
            #if user n has rating on item i
            similarUser = topUsers[n][0]
            #if self.dao.rating(similarUser,i) != 0:
            #这个源码的错误非常明显，因为如果不成立，会返回-1，返回-1之后反而会继续进行计算（-1减去-1)为0，导致下面的判断。
            if self.dao.rating(similarUser,i) > 0:
                similarity = topUsers[n][1]
                rating = self.dao.rating(similarUser,i)
                #这边和下面的 减平均和加平均是为了去除不同用户打分习惯的影响。
                sum += similarity*(rating-self.dao.userMeans[similarUser])
                denom += similarity
        if sum == 0:
            #no users have rating on item i,return the average rating of user u
            if not self.dao.containsUser(u):
                #user u has no ratings in the training set,return the global mean
                return self.dao.globalMean
            #这里，如果一个用户仅给一项数据打了很多分得话，会存在此项异常大
            return self.dao.userMeans[u]
        pred = self.dao.userMeans[u]+sum/float(denom)
        return pred


    def computeCorr(self):
        'compute correlation among users'
        # 计算待测的用户和所有用户之间的相似度
        print 'Computing user correlation...'
        for u1 in self.dao.testSet_u:

            for u2 in self.dao.user:
                if u1 <> u2:
                    #先判断两者关系是否已经存在，不存在的话就去生成
                    # sRow（表示u评价过u)item的列表字典。
                    if self.userSim.contains(u1,u2):
                        continue
                    sim = qmath.similarity(self.dao.sRow(u1),self.dao.sRow(u2),self.sim)
                    self.userSim.set(u1,u2,sim)
            print 'user '+u1+' finished.'
        print 'The user correlation has been figured out.'



